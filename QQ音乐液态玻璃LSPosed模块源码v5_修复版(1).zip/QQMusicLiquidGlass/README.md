# QQ 音乐液态玻璃底栏 LSPosed 模块（v1.1 修复版）

把 QQ 音乐全应用底部栏变成 iOS 风格「液态玻璃」：降采样实时快照 + `RenderEffect` 高斯模糊 + 半透明渐变 + 圆角高光。纯 APK 模块，**不修改任何系统分区**。

## v1.1 修复内容（针对"底栏/播放页完全不变玻璃"）

| # | 问题 | 修复 |
| --- | --- | --- |
| 1 | 缺 `assets/xposed_init`，部分 LSPosed/EdXposed 版本不加载模块 | 补上入口文件（与 manifest 声明双兼容） |
| 2 | QQ 音乐进程读 `/data/data/<模块>/shared_prefs/*.xml` 被 SELinux 静默拦截（`File.exists()` 吞异常返回 false），**用户设置永远不生效** | 新增 exported 只读 `GlassPrefsProvider`，目标进程通过 `ContentResolver` 查询配置 |
| 3 | 底栏识别要求"贴底 ±60dp + 宽 ≥90%"，而 QQ 音乐迷你播放器条/播放控制面板是**悬浮圆角卡片**（底部留白 60~90dp 含手势区），永远命不中 | 底部容差放宽至 130dp、宽度阈值降至 80%，并内置常见底栏 id 关键字可走宽松几何 |
| 4 | 父子同时命中时选最内层**无背景**子行，玻璃被外层白背景盖死 | 优先在"带背景"的候选中选最内层——背景才是要被玻璃替换的目标 |
| 5 | 给底栏 `addView` 硬塞 `FrameLayout.LayoutParams`，LinearLayout/ConstraintLayout 底栏会布局错乱 | 改为 FrameLayout 包裹方案：玻璃在底栏之下，底栏换 MATCH_PARENT，任何类型都安全 |
| 6 | 模糊半径单位是 px，35px 在高分屏仅约 11dp，几乎看不出模糊 | 按 dp × density 换算成 px |
| 7 | 设置广播未指定包名，Android 14+ 可能被系统丢弃 | 发送时 `setPackage("com.tencent.qqmusic")` |

`SnapshotView`（快照取样）与 `XposedInit` / `GlassController` / `PageRecordReceiver` 实现不变。

## 编译

1. 用 Android Studio（Koala 或更新）直接打开本工程，等待 Gradle 同步；
2. `Build > Build APK(s)` 产出 `app/build/outputs/apk/debug/app-debug.apk`。
   - compileSdk 35，若本机 SDK 未装对应平台，SDK Manager 里装一下即可。

## 安装与启用

1. 安装 APK 到手机；
2. LSPosed 管理器启用「QQ音乐液态玻璃」，作用域勾选 **QQ 音乐**；
3. **强制停止** QQ 音乐后重新打开；
4. 打开首页、播放页各停留几秒，底栏应立即变玻璃。

**排查**：若无效，去 LSPosed 日志搜 `QQMusicGlass`——看到 `模块已载入 com.tencent.qqmusic` 说明加载成功（问题在识别/参数）；完全没有输出说明模块没加载（检查作用域勾选、xposed_init、强制停止后是否重启）。

## 设置项

| 设置 | 说明 |
| --- | --- |
| 总开关 | 一键启用/停用全部效果 |
| 渲染模式 | 实时模糊（液态玻璃）/ 半透明渐变（省电，兼容 Android 12 以下） |
| 模糊半径 | 5–50 **dp** |
| 底色透明度 | 0–200 |
| 圆角 | 0–48dp |
| 刷新频率 | 每 N 帧重截背景（0 = 静态只截一次，最省电） |
| 深色跟随 | 夜间模式下自动切深色玻璃 |
| ID 白名单 | 启发式匹配漏掉/误伤时，填底栏资源 id 关键字（英文逗号分隔）强制命中 |
| 按页面启用 | 列出模块见过的 QQ 音乐页面，取消勾选即该页不生效 |

保存后立即生效，无需重启 QQ 音乐。

## 工作原理

- Hook `Activity.onResume/onPause` + DecorView 全局布局监听（600ms 节流）扫描当前窗口；
- 底栏识别：几何启发（宽 ≥80% 屏宽、底部距屏边 ≤130dp、高 40–200dp、子项 ≥2）+ id 关键字白名单；命中后优先取带背景的候选；
- 命中的底栏：备份并清空原背景 → 用 FrameLayout 包裹（玻璃层在 index 0，底栏内容之下）；
- 玻璃层内 `SnapshotView` 随 Choreographer 每 N 帧对 DecorView 做 1/8 降采样 `View.draw` 快照（截图瞬间临时隐藏玻璃层避免自捕获），只取底栏区域放大绘制，View 级 `RenderEffect.createBlurEffect` 实时模糊（dp 换算）；
- 配置存模块自身 `glass_prefs.xml`；QQ 音乐进程经 `GlassPrefsProvider`（exported 只读）查询，设置页保存后发显式广播实时刷新。

## 已知限制

- 播放页视频/SurfaceView 区域无法被 `View.draw` 捕获，快照里可能是黑色，模糊后表现为深色玻璃，属预期；
- QQ 音乐大版本更新若底栏样式变化，可在 `BarDetector.kt` 调整 130dp / 80% 阈值；
- 全应用启发式匹配可能误伤个别相似容器，用「按页面启用」或 ID 白名单兜底。
