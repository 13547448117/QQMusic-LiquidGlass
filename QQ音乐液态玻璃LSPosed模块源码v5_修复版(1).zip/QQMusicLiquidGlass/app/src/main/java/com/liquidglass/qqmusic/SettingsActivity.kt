package com.liquidglass.qqmusic

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.liquidglass.qqmusic.hook.GlassController

/**
 * 模块设置页：所有参数保存到 glass_prefs，
 * 保存后发广播，QQ 音乐进程实时生效（无需重启目标 App）。
 */
class SettingsActivity : Activity() {

    companion object {
        const val ACTION_SETTINGS_CHANGED =
            "com.liquidglass.qqmusic.ACTION_SETTINGS_CHANGED"
    }

    private lateinit var swEnabled: Switch
    private lateinit var spMode: Spinner
    private lateinit var sbBlur: SeekBar
    private lateinit var sbTint: SeekBar
    private lateinit var sbCorner: SeekBar
    private lateinit var sbRefresh: SeekBar
    private lateinit var swDark: Switch
    private lateinit var etIdWhitelist: EditText
    private lateinit var containerPages: LinearLayout
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        swEnabled = findViewById(R.id.swEnabled)
        spMode = findViewById(R.id.spMode)
        sbBlur = findViewById(R.id.sbBlur)
        sbTint = findViewById(R.id.sbTint)
        sbCorner = findViewById(R.id.sbCorner)
        sbRefresh = findViewById(R.id.sbRefresh)
        swDark = findViewById(R.id.swDark)
        etIdWhitelist = findViewById(R.id.etIdWhitelist)
        containerPages = findViewById(R.id.containerPages)
        btnSave = findViewById(R.id.btnSave)
        findViewById<Button>(R.id.btnPreset).setOnClickListener {
            spMode.setSelection(0)
            sbBlur.progress = 30      // 模糊半径 35
            sbTint.progress = 28      // 低透明度，通透感强
            sbCorner.progress = 26
            sbRefresh.progress = 2
            swDark.isChecked = true
            Toast.makeText(this, "已填入推荐参数，点「保存并应用」生效", Toast.LENGTH_SHORT).show()
        }

        spMode.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            arrayOf("实时模糊（液态玻璃）", "半透明渐变（省电）")
        )

        bindSeekLabels()
        loadPrefs()

        btnSave.setOnClickListener { savePrefs() }
    }

    private fun bindSeekLabels() {
        fun label(sb: SeekBar, tvRes: Int, fmt: (Int) -> String) {
            val tv = findViewById<TextView>(tvRes)
            tv.text = fmt(sb.progress)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    tv.text = fmt(p)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        label(sbBlur, R.id.tvBlurVal) { "模糊半径（dp）：${it + 5}" }
        label(sbTint, R.id.tvTintVal) { "底色透明度：$it" }
        label(sbCorner, R.id.tvCornerVal) { "圆角：${it}dp" }
        label(sbRefresh, R.id.tvRefreshVal) {
            if (it == 0) "刷新：静态（只截取一次）" else "刷新：每 $it 帧"
        }
    }

    private fun loadPrefs() {
        val p = getSharedPreferences("glass_prefs", Context.MODE_PRIVATE)
        swEnabled.isChecked = p.getBoolean("enabled", true)
        spMode.setSelection(if (p.getBoolean("blur_mode", true)) 0 else 1)
        sbBlur.progress = (p.getInt("blur_radius", 22) - 5).coerceIn(0, 45)
        sbTint.progress = p.getInt("tint_alpha", 70).coerceIn(0, 200)
        sbCorner.progress = p.getInt("corner_radius", 22).coerceIn(0, 48)
        sbRefresh.progress = p.getInt("refresh_frames", 2).coerceIn(0, 10)
        swDark.isChecked = p.getBoolean("dark_follow", true)
        etIdWhitelist.setText(p.getString("id_whitelist", ""))

        val disabled = p.getStringSet("disabled_pages", emptySet()) ?: emptySet()
        val seen = (p.getStringSet("seen_pages", emptySet()) ?: emptySet()).sorted()
        containerPages.removeAllViews()
        if (seen.isEmpty()) {
            val tv = TextView(this)
            tv.text = "（尚未记录到页面，先打开一次 QQ 音乐再回来）"
            tv.setTextColor(0xFF888888.toInt())
            containerPages.addView(tv)
        } else {
            for (page in seen) {
                val cb = CheckBox(this)
                cb.text = page.substringAfterLast('.')
                cb.tag = page
                cb.isChecked = page !in disabled
                containerPages.addView(cb)
            }
        }
    }

    private fun savePrefs() {
        val enabledPages = HashSet<String>()
        for (i in 0 until containerPages.childCount) {
            val child = containerPages.getChildAt(i)
            if (child is CheckBox) {
                val page = child.tag as? String ?: continue
                if (!child.isChecked) enabledPages.add(page) // 未勾选 = 禁用
            }
        }

        getSharedPreferences("glass_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("enabled", swEnabled.isChecked)
            .putBoolean("blur_mode", spMode.selectedItemPosition == 0)
            .putInt("blur_radius", sbBlur.progress + 5)
            .putInt("tint_alpha", sbTint.progress)
            .putInt("corner_radius", sbCorner.progress)
            .putInt("refresh_frames", sbRefresh.progress)
            .putBoolean("dark_follow", swDark.isChecked)
            .putString("id_whitelist", etIdWhitelist.text.toString().trim())
            .putStringSet("disabled_pages", enabledPages)
            .apply()

        // 通知 QQ 音乐进程实时刷新
        try {
            // Android 14+ 隐式广播必须显式指定目标包，否则会被系统丢弃
            sendBroadcast(Intent(ACTION_SETTINGS_CHANGED).setPackage(GlassController.TARGET_PKG))
        } catch (_: Throwable) {
        }

        Toast.makeText(this, "已保存，切回 QQ 音乐即可生效", Toast.LENGTH_SHORT).show()
    }
}
