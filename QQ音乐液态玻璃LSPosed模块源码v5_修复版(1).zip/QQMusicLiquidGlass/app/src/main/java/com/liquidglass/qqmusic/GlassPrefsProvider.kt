package com.liquidglass.qqmusic

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri

/**
 * 跨进程配置桥：QQ 音乐进程无权读模块的 /data/data 目录（SELinux），
 * 改为 query 这个只读 Provider 获取 glass_prefs 配置。
 */
class GlassPrefsProvider : ContentProvider() {

    companion object {
        const val AUTHORITY = "com.liquidglass.qqmusic.glassprefs"
        private const val SET_SEPARATOR = "\u001F" // 字符串集分隔符，避免与内容冲突
    }

    override fun onCreate(): Boolean = true

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        val cursor = MatrixCursor(arrayOf("key", "type", "value"))
        try {
            val p = context!!.getSharedPreferences("glass_prefs", Context.MODE_PRIVATE)
            for ((k, v) in p.all) {
                when (v) {
                    is Boolean -> cursor.addRow(arrayOf(k, "boolean", if (v) "1" else "0"))
                    is Int -> cursor.addRow(arrayOf(k, "int", v.toString()))
                    is String -> cursor.addRow(arrayOf(k, "string", v))
                    is Set<*> -> cursor.addRow(
                        arrayOf(k, "set", v.filterIsInstance<String>().joinToString(SET_SEPARATOR))
                    )
                    else -> Unit
                }
            }
        } catch (_: Throwable) {
        }
        return cursor
    }

    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(
        uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?
    ): Int = 0
}
