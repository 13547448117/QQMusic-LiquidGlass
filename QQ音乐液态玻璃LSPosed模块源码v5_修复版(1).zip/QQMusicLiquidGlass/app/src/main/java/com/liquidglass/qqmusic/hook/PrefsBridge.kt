package com.liquidglass.qqmusic.hook

import android.content.Context
import android.net.Uri

/**
 * 模块配置。所有字段与设置页一一对应。
 */
data class GlassConfig(
    val enabled: Boolean = true,
    val blurMode: Boolean = true,      // true=实时模糊，false=半透明渐变
    val blurRadius: Int = 22,        // 模糊半径（dp）
    val tintAlpha: Int = 70,         // 底色透明度 0-200
    val cornerRadiusDp: Int = 22,    // 圆角 dp
    val refreshFrames: Int = 2,      // 每 N 帧刷新快照；0=静态只截一次
    val darkFollow: Boolean = true,   // 深色跟随系统夜间模式
    val disabledPages: Set<String> = emptySet(),
    val idWhitelist: String = ""
)

/**
 * 跨进程读取模块配置：
 * - 模块自身进程：直接读 SharedPreferences；
 * - QQ 音乐进程：query 模块的 GlassPrefsProvider（模块私有目录跨进程不可读，
 *   旧版直接解析其 xml 配置文件会被 SELinux 静默拦截，导致设置永远不生效）。
 */
object PrefsBridge {

    private const val PREFS_NAME = "glass_prefs"
    private const val AUTHORITY = "com.liquidglass.qqmusic.glassprefs"
    private const val SET_SEPARATOR = "\u001F"

    private var cache: GlassConfig? = null
    private var cacheTime = 0L

    fun read(context: Context): GlassConfig {
        val now = System.currentTimeMillis()
        cache?.let { if (now - cacheTime < 2000) return it }
        cacheTime = now
        val cfg = if (context.packageName == GlassController.MODULE_PKG) {
            readFromPrefs(context)
        } else {
            readFromProvider(context)
        }
        cache = cfg
        return cfg
    }

    fun invalidate() {
        cache = null
    }

    private fun readFromPrefs(context: Context): GlassConfig {
        val p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return GlassConfig(
            enabled = p.getBoolean("enabled", true),
            blurMode = p.getBoolean("blur_mode", true),
            blurRadius = p.getInt("blur_radius", 22),
            tintAlpha = p.getInt("tint_alpha", 70),
            cornerRadiusDp = p.getInt("corner_radius", 22),
            refreshFrames = p.getInt("refresh_frames", 2),
            darkFollow = p.getBoolean("dark_follow", true),
            disabledPages = p.getStringSet("disabled_pages", emptySet()) ?: emptySet(),
            idWhitelist = p.getString("id_whitelist", "") ?: ""
        )
    }

    private fun readFromProvider(context: Context): GlassConfig {
        return try {
            context.contentResolver.query(
                Uri.parse("content://$AUTHORITY/prefs"), null, null, null, null
            )?.use { c ->
                val bools = HashMap<String, Boolean>()
                val ints = HashMap<String, Int>()
                val strs = HashMap<String, String>()
                val sets = HashMap<String, Set<String>>()
                val ki = c.getColumnIndex("key")
                val ti = c.getColumnIndex("type")
                val vi = c.getColumnIndex("value")
                if (ki < 0 || ti < 0 || vi < 0) return GlassConfig()
                while (c.moveToNext()) {
                    val k = c.getString(ki) ?: continue
                    when (c.getString(ti)) {
                        "boolean" -> bools[k] = c.getString(vi) == "1"
                        "int" -> ints[k] = c.getString(vi)?.toIntOrNull() ?: 0
                        "string" -> strs[k] = c.getString(vi) ?: ""
                        "set" -> sets[k] = (c.getString(vi) ?: "")
                            .split(SET_SEPARATOR).filter { it.isNotEmpty() }.toSet()
                    }
                }
                GlassConfig(
                    enabled = bools["enabled"] ?: true,
                    blurMode = bools["blur_mode"] ?: true,
                    blurRadius = ints["blur_radius"] ?: 22,
                    tintAlpha = ints["tint_alpha"] ?: 70,
                    cornerRadiusDp = ints["corner_radius"] ?: 22,
                    refreshFrames = ints["refresh_frames"] ?: 2,
                    darkFollow = bools["dark_follow"] ?: true,
                    disabledPages = sets["disabled_pages"] ?: emptySet(),
                    idWhitelist = strs["id_whitelist"] ?: ""
                )
            } ?: GlassConfig()
        } catch (t: Throwable) {
            GlassConfig()
        }
    }
}
