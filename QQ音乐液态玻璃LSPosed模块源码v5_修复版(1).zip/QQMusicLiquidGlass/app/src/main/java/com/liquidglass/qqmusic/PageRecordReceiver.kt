package com.liquidglass.qqmusic

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * 接收 QQ 音乐进程上报的页面名，累积到 seen_pages，
 * 供设置页"单页开关"列表使用。
 */
class PageRecordReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "com.liquidglass.qqmusic.ACTION_PAGE_SEEN") return
        val page = intent.getStringExtra("page") ?: return
        if (page.length > 200) return

        val prefs = context.getSharedPreferences("glass_prefs", Context.MODE_PRIVATE)
        val seen = (prefs.getStringSet("seen_pages", emptySet()) ?: emptySet()).toMutableSet()
        if (seen.size > 100) return // 防御性上限
        if (seen.add(page)) {
            prefs.edit().putStringSet("seen_pages", seen).apply()
        }
    }
}
