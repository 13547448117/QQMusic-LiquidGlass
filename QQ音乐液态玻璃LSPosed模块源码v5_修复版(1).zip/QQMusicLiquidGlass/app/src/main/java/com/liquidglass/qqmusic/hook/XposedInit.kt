package com.liquidglass.qqmusic.hook

import android.app.Activity
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * LSPosed 模块入口：注入 QQ 音乐进程，hook Activity 生命周期。
 */
class XposedInit : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != GlassController.TARGET_PKG) return
        XposedBridge.log("[QQMusicGlass] 模块已载入 ${lpparam.packageName}")

        XposedHelpers.findAndHookMethod(
            Activity::class.java, "onResume",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    try {
                        GlassController.onActivityResumed(param.thisObject as Activity)
                    } catch (t: Throwable) {
                        XposedBridge.log("[QQMusicGlass] onResume hook 异常: $t")
                    }
                }
            }
        )

        XposedHelpers.findAndHookMethod(
            Activity::class.java, "onPause",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    try {
                        GlassController.onActivityPaused(param.thisObject as Activity)
                    } catch (t: Throwable) {
                        XposedBridge.log("[QQMusicGlass] onPause hook 异常: $t")
                    }
                }
            }
        )
    }
}
