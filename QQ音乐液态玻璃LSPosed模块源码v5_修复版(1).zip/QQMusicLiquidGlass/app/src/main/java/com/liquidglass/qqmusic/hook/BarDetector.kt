package com.liquidglass.qqmusic.hook

import android.view.View
import android.view.ViewGroup
import com.liquidglass.qqmusic.R

/**
 * 底栏启发式识别。
 * QQ 音乐资源 ID 混淆且随版本变化，因此以几何特征为主、id 关键字白名单为辅。
 *
 * v1.1 修复：QQ 音乐的迷你播放器条 / 播放页控制面板是"悬浮圆角卡片"，
 * 底部离屏幕边 60~90dp（含手势导航区），旧版"贴底 ±60dp + 宽 ≥90%"永远命不中；
 * 且父子同时命中时旧版选最内层无背景子行，玻璃会被外层白背景盖死。
 */
object BarDetector {

    /** 常见底栏资源 id 关键字（未混淆部分），命中可走宽松几何 */
    private val BUILTIN_ID_KEYS = listOf(
        "mini_player", "miniplayer", "mini_play", "player_bar", "play_bar", "playbar",
        "bottom_bar", "tab_bar", "tabbar", "tab_layout", "tablayout",
        "control_bar", "control_panel", "now_bar", "nowbar", "dock"
    )

    fun detect(decor: View, cfg: GlassConfig): List<ViewGroup> {
        val candidates = ArrayList<ViewGroup>()
        val dm = decor.resources.displayMetrics
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels
        val density = dm.density
        val loc = IntArray(2)
        val userKeys = cfg.idWhitelist.split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        fun entryName(v: View): String? =
            if (v.id == View.NO_ID) null
            else try {
                v.resources.getResourceEntryName(v.id)
            } catch (_: Throwable) {
                null
            }

        fun matches(v: ViewGroup): Boolean {
            v.getLocationOnScreen(loc)
            val bottomGap = screenH - (loc[1] + v.height)
            val hDp = v.height / density
            val wRatio = v.width / screenW.toFloat()

            // 用户白名单 / 内置关键字：宽松几何即可命中
            val name = entryName(v)
            if (name != null && (
                userKeys.any { name.contains(it, ignoreCase = true) } ||
                    BUILTIN_ID_KEYS.any { name.contains(it, ignoreCase = true) })
            ) {
                return bottomGap <= 220 * density && hDp in 24f..280f && wRatio >= 0.5f
            }

            // 几何启发：兼容悬浮圆角卡片（底部容差含手势导航区）
            return wRatio >= 0.8f &&
                bottomGap <= 130 * density &&
                hDp >= 40f && hDp <= 200f &&
                v.childCount >= 2
        }

        fun walk(v: View) {
            if (v.visibility != View.VISIBLE) return
            if (v.width <= 0 || v.height <= 0) return
            if (v !is ViewGroup) return
            if (v.getTag(R.id.tag_wrapper) != null) return // 已包裹过的容器跳过
            if (matches(v) && candidates.none { it === v }) candidates.add(v)
            for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }

        walk(decor)

        fun isAncestor(outer: ViewGroup, inner: View): Boolean {
            var p = inner.parent
            while (p is View) {
                if (p === outer) return true
                p = (p as View).parent
            }
            return false
        }

        fun innermostOf(list: List<ViewGroup>): List<ViewGroup> =
            list.filter { outer ->
                list.none { inner -> inner !== outer && isAncestor(outer, inner) }
            }

        // 悬浮卡片常见结构：外层圆角卡片（带背景）+ 内层内容行（无背景）。
        // 优先在"带背景"的候选里挑最内层——背景才是要被玻璃替换的目标。
        val withBg = candidates.filter { it.background != null }
        return if (withBg.isNotEmpty()) innermostOf(withBg) else innermostOf(candidates)
    }
}
