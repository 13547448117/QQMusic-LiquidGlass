package com.liquidglass.qqmusic.hook

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Choreographer
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import com.liquidglass.qqmusic.R
import de.robv.android.xposed.XposedBridge
import java.util.WeakHashMap

/**
 * 液态玻璃渲染（v1.1）：
 * 1. 备份并清空底栏原背景；
 * 2. 用 FrameLayout 包裹底栏：玻璃层在 index 0（底栏内容之下），
 *    底栏换回 MATCH_PARENT——对 LinearLayout / CardView / ConstraintLayout 等
 *    任何底栏类型都不会破坏原布局（旧版硬塞 FrameLayout.LayoutParams 会错乱）；
 * 3. 玻璃层 = 降采样快照 + RenderEffect 实时高斯模糊 + 半透明渐变 tint + 圆角裁切；
 * 4. SDK < 31 或省电模式时降级为纯半透明渐变。
 */
object GlassRenderer {

    private val layers = WeakHashMap<View, GlassLayer>()

    fun apply(activity: Activity, bar: ViewGroup, cfg: GlassConfig) {
        try {
            layers[bar]?.let {
                it.updateConfig(cfg)
                return
            }
            if (bar.getTag(R.id.tag_glass) != null) return

            val parent = bar.parent as? ViewGroup ?: return
            val index = parent.indexOfChild(bar)
            if (index < 0) return

            bar.setTag(R.id.tag_original_bg, bar.background)
            bar.background = null
            bar.setTag(R.id.tag_glass, true)

            val layer = GlassLayer(activity, bar, cfg)

            val wrapper = FrameLayout(activity)
            wrapper.layoutParams = layer.originalBarLp
            wrapper.clipToOutline = true
            wrapper.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, outline: Outline) {
                    val r = cfg.cornerRadiusDp * v.resources.displayMetrics.density
                    outline.setRoundRect(0, 0, v.width, v.height, r)
                }
            }
            wrapper.setTag(R.id.tag_wrapper, true) // 检测时跳过，防止二次包裹

            wrapper.addView(
                layer.view, 0,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            wrapper.addView(
                bar,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )

            layers[bar] = layer
            parent.removeViewAt(index)
            parent.addView(wrapper, index)
        } catch (t: Throwable) {
            XposedBridge.log("[QQMusicGlass] apply 异常: $t")
        }
    }

    /**
     * 清理过期玻璃层（带去抖）：
     * - 已脱离窗口/不可见的层立即移除；
     * - 仍附着但本次未命中的层，连续两次扫描都未命中才移除，
     *   避免识别结果在两个容器间抖动时玻璃层反复拆装产生闪烁。
     */
    private var pendingRemoval = HashSet<View>()

    fun cleanupStale(current: List<View>) {
        val stillPending = HashSet<View>()
        for (bar in layers.keys.toList()) {
            if (!bar.isAttachedToWindow || bar.visibility != View.VISIBLE) {
                removeLayer(bar)
                continue
            }
            if (current.none { it === bar }) {
                if (pendingRemoval.contains(bar)) {
                    removeLayer(bar)
                } else {
                    stillPending.add(bar)
                }
            }
        }
        pendingRemoval = stillPending
    }

    fun removeAll() {
        for (bar in layers.keys.toList()) removeLayer(bar)
        layers.clear()
    }

    fun stopLoopsFor(activity: Activity) {
        for ((bar, layer) in layers) {
            if (findActivity(bar) === activity) layer.stopLoop()
        }
    }

    private fun removeLayer(bar: View) {
        val layer = layers.remove(bar) ?: return
        layer.stopLoop()
        try {
            val wrapper = layer.view.parent as? ViewGroup
            val parent = wrapper?.parent as? ViewGroup
            if (wrapper != null && parent != null) {
                val idx = parent.indexOfChild(wrapper)
                wrapper.removeView(bar)
                bar.layoutParams = layer.originalBarLp
                if (idx >= 0) {
                    parent.removeViewAt(idx)
                    parent.addView(bar, idx)
                }
            }
            layer.destroy()
            bar.background = bar.getTag(R.id.tag_original_bg) as? Drawable
        } catch (_: Throwable) {
        }
        bar.setTag(R.id.tag_glass, null)
        bar.setTag(R.id.tag_original_bg, null)
    }

    private fun findActivity(v: View): Activity? {
        var ctx: Context? = v.context
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    // ------------------------------------------------------------------

    class GlassLayer(
        private val activity: Activity,
        private val bar: View,
        cfg: GlassConfig
    ) {
        val view: FrameLayout = FrameLayout(activity)
        val originalBarLp: ViewGroup.LayoutParams = bar.layoutParams ?: ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        private var snapshot: SnapshotView? = null
        private val tint = View(activity)
        private var cfg: GlassConfig = cfg
        private var configured = false
        private var frameCallback: Choreographer.FrameCallback? = null
        private var frameCount = 0

        init {
            view.isClickable = false
            view.isFocusable = false
            view.clipToOutline = true
            view.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, outline: Outline) {
                    val r = this@GlassLayer.cfg.cornerRadiusDp *
                        v.resources.displayMetrics.density
                    outline.setRoundRect(0, 0, v.width, v.height, r)
                }
            }
            view.addView(
                tint,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            updateConfig(cfg)

            view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) = startLoop()
                override fun onViewDetachedFromWindow(v: View) = stopLoop()
            })
        }

        fun updateConfig(c: GlassConfig) {
            if (configured && c == cfg) return
            configured = true
            cfg = c
            view.invalidateOutline()

            val blurPossible = c.blurMode && Build.VERSION.SDK_INT >= 31
            if (blurPossible && snapshot == null) {
                val sv = SnapshotView(activity)
                snapshot = sv
                view.addView(
                    sv, 0,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
            } else if (!blurPossible && snapshot != null) {
                view.removeView(snapshot)
                snapshot = null
            }

            if (Build.VERSION.SDK_INT >= 31) {
                // 模糊半径按 dp 换算成 px：旧版直接用 px，35px 在高分屏
                // 只有约 11dp，几乎看不出模糊
                val rPx = (c.blurRadius *
                    view.resources.displayMetrics.density).coerceIn(1f, 220f)
                snapshot?.setRenderEffect(
                    RenderEffect.createBlurEffect(rPx, rPx, Shader.TileMode.CLAMP)
                )
            }

            // tint：顶部高光 → 半透明底色，深色模式跟随
            val dark = if (c.darkFollow) isNight(activity) else false
            val baseAlpha = c.tintAlpha
            val base = if (dark) Color.argb(baseAlpha, 24, 24, 28)
            else Color.argb(baseAlpha, 255, 255, 255)
            val top = if (dark) Color.argb(46, 255, 255, 255)
            else Color.argb(70, 255, 255, 255)
            val stroke = if (dark) Color.argb(28, 255, 255, 255)
            else Color.argb(110, 255, 255, 255)
            val r = c.cornerRadiusDp * activity.resources.displayMetrics.density
            tint.background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(top, base, base)
            ).apply {
                cornerRadius = r
                setStroke(1, stroke)
            }

            startLoop()
        }

        fun destroy() {
            snapshot?.release()
            snapshot = null
        }

        private fun startLoop() {
            val sv = snapshot ?: return
            stopLoop()
            if (cfg.refreshFrames <= 0) {
                // 静态模式：只截一次
                sv.update(activity, bar)
                return
            }
            val cb = object : Choreographer.FrameCallback {
                override fun doFrame(frameTimeNanos: Long) {
                    frameCount++
                    if (frameCount % cfg.refreshFrames.coerceAtLeast(1) == 0) {
                        snapshot?.update(activity, bar)
                    }
                    Choreographer.getInstance().postFrameCallback(this)
                }
            }
            frameCallback = cb
            Choreographer.getInstance().postFrameCallback(cb)
        }

        fun stopLoop() {
            frameCallback?.let { Choreographer.getInstance().removeFrameCallback(it) }
            frameCallback = null
        }

        private fun isNight(context: Context): Boolean {
            val mode = context.resources.configuration.uiMode and
                android.content.res.Configuration.UI_MODE_NIGHT_MASK
            return mode == android.content.res.Configuration.UI_MODE_NIGHT_YES
        }
    }

    // ------------------------------------------------------------------

    /**
     * 对 DecorView 做 1/8 降采样快照，只显示底栏所在区域并放大绘制。
     * 模糊由外层 RenderEffect 完成，本类只负责取图。（实现不变）
     */
class SnapshotView(context: Context) : View(context) {

        private var bmp: Bitmap? = null
        private var smallW = 0
        private var smallH = 0
        private val src = Rect()
        private val dst = Rect()
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val barLoc = IntArray(2)
        private val decorLoc = IntArray(2)

        companion object {
            private const val DOWNSCALE = 8f
            private const val EDGE_PAD = 12 // 快照外扩像素，遮模糊白边
        }

        fun update(activity: Activity, bar: View) {
            try {
                val decor = activity.window?.decorView ?: return
                if (decor.width <= 0 || decor.height <= 0) return

                val w = (decor.width / DOWNSCALE).toInt().coerceAtLeast(1)
                val h = (decor.height / DOWNSCALE).toInt().coerceAtLeast(1)
                var b = bmp
                if (b == null || b.width != w || b.height != h) {
                    b?.recycle()
                    b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp = b
                    smallW = w
                    smallH = h
                }

                // 捕获期间临时隐藏玻璃层，避免递归自捕获
                val container = parent as? View
                val prevVis = container?.visibility
                container?.visibility = View.INVISIBLE

                val canvas = Canvas(b)
                canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
                canvas.scale(w / decor.width.toFloat(), h / decor.height.toFloat())
                decor.draw(canvas)

                container?.visibility = prevVis ?: View.VISIBLE

                bar.getLocationOnScreen(barLoc)
                decor.getLocationOnScreen(decorLoc)
                val fx = smallW / decor.width.toFloat()
                val fy = smallH / decor.height.toFloat()
                val l = ((barLoc[0] - decorLoc[0]) * fx).toInt()
                val t = ((barLoc[1] - decorLoc[1]) * fy).toInt()
                val r = l + (bar.width * fx).toInt()
                val bo = t + (bar.height * fy).toInt()
                src.set(
                    (l - EDGE_PAD).coerceAtLeast(0),
                    (t - EDGE_PAD).coerceAtLeast(0),
                    (r + EDGE_PAD).coerceAtMost(smallW),
                    (bo + EDGE_PAD).coerceAtMost(smallH)
                )
                invalidate()
            } catch (t: Throwable) {
                XposedBridge.log("[QQMusicGlass] 快照异常: $t")
            }
        }

        override fun onDraw(canvas: Canvas) {
            val b = bmp ?: return
            if (src.isEmpty) return
            // 轻微过绘，避免模糊边缘出现透明缝隙
            dst.set(-20, -20, width + 20, height + 20)
            canvas.drawBitmap(b, src, dst, paint)
        }

        fun release() {
            bmp?.recycle()
            bmp = null
        }
    }
}
