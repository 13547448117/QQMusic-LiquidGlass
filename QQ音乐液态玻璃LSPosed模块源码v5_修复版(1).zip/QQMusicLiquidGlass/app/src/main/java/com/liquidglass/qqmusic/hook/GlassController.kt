package com.liquidglass.qqmusic.hook

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.SystemClock
import android.view.View
import android.view.ViewTreeObserver
import de.robv.android.xposed.XposedBridge
import java.util.WeakHashMap

/**
 * 玻璃效果总控：跟踪当前 Activity、布局变化重扫、设置变更广播。
 */
object GlassController {

    const val TARGET_PKG = "com.tencent.qqmusic"
    const val MODULE_PKG = "com.liquidglass.qqmusic"
    const val ACTION_SETTINGS_CHANGED = "com.liquidglass.qqmusic.ACTION_SETTINGS_CHANGED"
    const val ACTION_PAGE_SEEN = "com.liquidglass.qqmusic.ACTION_PAGE_SEEN"

    private var currentActivity: Activity? = null
    private val layoutListeners = WeakHashMap<Activity, ViewTreeObserver.OnGlobalLayoutListener>()
    private var receiverRegistered = false
    private var lastScan = 0L

    fun onActivityResumed(activity: Activity) {
        currentActivity = activity
        reportPage(activity)
        registerReceiver(activity)

        val decor = activity.window?.decorView ?: return
        decor.post { rescan(activity) }

        if (layoutListeners[activity] == null) {
            val listener = object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastScan < 600) return
                    lastScan = now
                    currentActivity?.let { rescan(it) }
                }
            }
            layoutListeners[activity] = listener
            decor.viewTreeObserver.addOnGlobalLayoutListener(listener)
        }
    }

    fun onActivityPaused(activity: Activity) {
        if (currentActivity === activity) currentActivity = null
        layoutListeners.remove(activity)?.let { l ->
            try {
                activity.window?.decorView?.viewTreeObserver?.removeOnGlobalLayoutListener(l)
            } catch (_: Throwable) {
            }
        }
        GlassRenderer.stopLoopsFor(activity)
    }

    /** 把当前页面名上报给模块 App，供设置页"单页开关"列表使用 */
    private fun reportPage(activity: Activity) {
        try {
            activity.sendBroadcast(
                Intent(ACTION_PAGE_SEEN)
                    .setPackage(MODULE_PKG)
                    .putExtra("page", activity.javaClass.name)
            )
        } catch (_: Throwable) {
        }
    }

    fun rescan(activity: Activity) {
        try {
            val cfg = PrefsBridge.read(activity)
            val decor = activity.window?.decorView ?: return
            val pageDisabled = activity.javaClass.name in cfg.disabledPages

            if (!cfg.enabled || pageDisabled) {
                GlassRenderer.removeAll()
                return
            }

            val bars = BarDetector.detect(decor, cfg)
            // 带防抖的清理：仍在屏且命中的层保留并原地更新参数，避免闪烁
            GlassRenderer.cleanupStale(bars)
            for (bar in bars) {
                GlassRenderer.apply(activity, bar, cfg)
            }
        } catch (t: Throwable) {
            XposedBridge.log("[QQMusicGlass] rescan 异常: $t")
        }
    }

    private fun registerReceiver(context: Context) {
        if (receiverRegistered) return
        receiverRegistered = true
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                PrefsBridge.invalidate()
                currentActivity?.let { rescan(it) }
            }
        }
        val filter = IntentFilter(ACTION_SETTINGS_CHANGED)
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(receiver, filter)
            }
        } catch (t: Throwable) {
            XposedBridge.log("[QQMusicGlass] 注册广播失败: $t")
        }
    }
}
