# 保留 Xposed 入口类
-keep class com.liquidglass.qqmusic.hook.XposedInit { *; }
-keep class de.robv.android.xposed.** { *; }
